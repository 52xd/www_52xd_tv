<?php
//欢迎使用BH采集插件
//Awx博客采集插件，官网地址：www.awx88.cn
?>
<?php
namespace addons\collect;
use think\Addons;
class collect extends Addons 
{
	public function install() 
	{
		return true;
	}
	public function uninstall() 
	{
		return true;
	}
}
?>