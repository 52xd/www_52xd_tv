<?php
//欢迎使用BH采集插件
//Awx博客采集插件，官网地址：www.awx88.cn
?>
<?php
$path = 'application/data/config/quickmenu.txt';
$far = @require ('application/extra/maccms.php');
$info = 'BH采集插件,' . $far['site']['install_dir'] . 'addons/collect/bhkj.php';
if (stristr(file_get_contents($path), $info)) exit('快捷菜单已存在，请刷新页面后，在 后台首页>>快捷菜单 中查找【BH采集插件】菜单');
elseif (file_put_contents($path, "
" . $info, FILE_APPEND)) exit('快捷菜单添加成功，请刷新页面后，在 后台首页>>快捷菜单 中查找【BH采集插件】菜单');
else exit('快捷菜单添加失败，请检查文件权限或者查看是否被防火墙拦截');
?>