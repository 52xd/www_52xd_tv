<?php
$Far=array (
  'mengqing' => 
  array (
    'status' => '1',
    'terminal' => 'pc|android|ios|weixin|qq|bsl',
    'interval' => 
    array (
      'type' => '2',
      'time' => '1',
      'number' => '3',
    ),
    'title' => '手动弹窗代码部分',
    'type' => '2',
    'content' => 
    array (
      'image' => '',
      'text' => '手动弹窗代码部分
手动弹窗代码部分',
    ),
    'leftbutton' => 
    array (
      'name' => '手动弹',
      'url' => '/',
    ),
    'rightbutton' => 
    array (
      'name' => '窗代码部分',
      'url' => '/',
    ),
    'snow' => 
    array (
      'status' => '1',
      'type' => '1',
      'image' => '',
    ),
  ),
  'Hmengqing' => 
  array (
    'title' => '',
    'type' => '0',
    'content' => 
    array (
      'image' => '',
      'text' => '',
    ),
    'leftbutton' => 
    array (
      'name' => '',
      'url' => '',
    ),
    'rightbutton' => 
    array (
      'name' => '',
      'url' => '',
    ),
  ),
);
