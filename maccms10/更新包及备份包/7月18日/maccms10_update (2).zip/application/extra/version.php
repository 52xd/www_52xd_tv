<?php
return array (
    'name' => '苹果CMS',
    'copyright' => 'MacCMS.LA',
    'url' => '//www.maccms.la/',
    'code' => '2020.1000.1034',
    'license' => '免费版',
);
?>